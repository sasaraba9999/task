package com.example.task.project;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class ProjectEntity {
    private String projectId;
    private String projectName;
}
