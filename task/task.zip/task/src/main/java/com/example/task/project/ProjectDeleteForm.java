package com.example.task.project;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProjectDeleteForm {

        private String projectId ;
    }
