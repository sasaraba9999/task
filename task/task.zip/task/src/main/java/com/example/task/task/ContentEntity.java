package com.example.task.task;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class ContentEntity {
    private String contentName;
}
