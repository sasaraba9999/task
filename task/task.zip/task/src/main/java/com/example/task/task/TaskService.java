package com.example.task.task;

import com.example.task.project.ProjectEntity;
import com.example.task.project.ProjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service    //ビジネスロジック層　&　Bean登録
@RequiredArgsConstructor    //Lombokでコンストラクタ生成
public class TaskService {

    private final TaskRepository taskRepository;

    public List<TaskEntity> findTaskId(int taskId, String loginName) {
        return taskRepository.findTaskId(taskId,loginName);
    }

    public ContentEntity findContentId(int contentId, String loginName) {
        return taskRepository.findContentId(contentId,loginName);
    }
}
