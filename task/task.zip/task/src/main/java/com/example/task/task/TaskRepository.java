package com.example.task.task;

import com.example.task.project.ProjectEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface TaskRepository {

   @Select("select task.taskId ,task.taskName from task,users where task.userId=users.userId and task.projectId=#{taskId} and users.userName=#{loginName}")
    List<TaskEntity> findTaskId(int taskId,String loginName);

   @Select("select content.contentName from content,users where content.userId=users.userId and content.contentId=#{contentId} and users.userName=#{loginName}")
    ContentEntity findContentId(int contentId, String loginName);
}